import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
// import './App.css'
import SearchMovie from "./components/SearchMovie"
function App() {


  return (
    <>
<h1>Movie Search App</h1>    

<SearchMovie/> 
    </>
  )
}

export default App
